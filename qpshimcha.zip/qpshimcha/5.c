#include <stdio.h>

int main() {
    int n,s=0;

    int a[9] = {5, -4, 34, 60 , 54, -77, 80, -92};


    for (int i = 0; i < 9; i++) {
        s+=a[i];
        
    }
    printf("S=%d",s);
    return 0;
}
