#include <stdio.h>

int main() {
    int n, k = 0;
    scanf("%d", &n);
    int a[8] = {5, 1, 3, 7, 4, 6, 9, 0};

    for (int i = 0; i < 8; i++) {
        if (a[i] == n) {
            printf("bor\n");
            k = 1;
            break;
        }
    }

    if (k == 0) {
        printf("yoq\n");
    }

    return 0;
}
