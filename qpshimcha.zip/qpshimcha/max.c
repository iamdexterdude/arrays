#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void max_max(int A[],int n){
    int max=A[0];
srand(time(NULL));
for(int i=1; i<=n; i++){
    if(i>max) max=i;
    
}
    printf("max=%d",max);
}
int main (){
    int n,i;
    printf("==");
    scanf("%d",&n);
    max_max(i,n);
}