#include <stdio.h>

int main() {
    int n;
  
    int a[13] = {-4, 3, 46, 0, 18, 27, 97, -11, -21, 24, 16, 18, -55};

    for (int i = 0; i < 13; i++) {
        if (a[i] % 2!=0) {
            printf("%d\n",a[i]);
          
          
        }
    }

    return 0;
}
